document.write('<script type="text/javascript" src="../scripts/sh_main.min.js"></script>');
document.write('<script type="text/javascript" src="../scripts/sh_sql.min.js"></script>');
document.write('<script type="text/javascript" src="../scripts/numberLines.js"></script>');
document.write('<link rel="stylesheet" type="text/css" href="../scripts/sh_ide-msvcpp.min.css" />');
document.write('<link rel="stylesheet" type="text/css" href="../scripts/sqlcc.css" />');

function load() {
	sh_highlightDocument();
	if (navigator.appName != 'Microsoft Internet Explorer')
		numberLines(document.getElementsByTagName('pre')[0], 1, true);
}